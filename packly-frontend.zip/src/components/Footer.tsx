export default function Footer() {
  return (
    <footer className="text-center p-4 border-t mt-12 text-sm">
      &copy; 2025 Packly. All rights reserved.
    </footer>
  );
}