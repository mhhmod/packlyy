export default function HeroSection() {
  return (
    <section className="text-center py-20 px-4 bg-gray-100 dark:bg-gray-900">
      <h1 className="text-4xl font-bold mb-4">Create Your Website</h1>
      <p className="text-lg mb-6">Get custom commercial websites up and running quickly and easily.</p>
      <button className="bg-blue-600 text-white px-6 py-2 rounded">Get Started</button>
    </section>
  );
}