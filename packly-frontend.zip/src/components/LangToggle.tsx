'use client';
import { useState } from 'react';

export default function LangToggle() {
  const [lang, setLang] = useState('en');

  const toggleLang = () => {
    setLang(lang === 'en' ? 'ar' : 'en');
    document.documentElement.lang = lang === 'en' ? 'ar' : 'en';
    document.documentElement.dir = lang === 'en' ? 'rtl' : 'ltr';
  };

  return (
    <button onClick={toggleLang}>
      🌐 {lang.toUpperCase()}
    </button>
  );
}