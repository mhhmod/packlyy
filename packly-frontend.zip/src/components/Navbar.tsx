'use client';
import ThemeToggle from './ThemeToggle';
import LangToggle from './LangToggle';

export default function Navbar() {
  return (
    <nav className="flex justify-between items-center p-4 border-b">
      <div className="text-xl font-bold">Packly</div>
      <div className="flex gap-4">
        <a href="/">Home</a>
        <a href="/packs">Packs</a>
        <a href="/dashboard">Dashboard</a>
        <ThemeToggle />
        <LangToggle />
        <button className="border px-3 py-1 rounded">Login</button>
      </div>
    </nav>
  );
}